﻿using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.API.Util;
using Vintagestory.GameContent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;




namespace WildcraftFruitTrees
{
    public class WildcraftFruitTreeSystem : ModSystem
    {
        public override void Start(ICoreAPI api)
        {
            base.Start(api);

            api.RegisterBlockClass("BlockCoconutTree", typeof(BlockCoconutTree));
            api.RegisterBlockClass("BlockCoconutFruit", typeof(BlockCoconutTree));
            api.RegisterBlockEntityClass("BlockEntityCoconutFruit", typeof(BlockEntityCoconutFruit));
        }
    }

    public class BlockCoconutTree : Block, ITreeGenerator
    {
        public Block trunkThickness6;
        public Block trunkThickness7;
        public Block trunkThickness8;
        public Block trunkThickness9;
        public Block trunkThickness10;
        public Block trunkTopEmpty;
        public Block trunkTopFlowering;
        public Block trunkTopUnripe;
        public Block trunkTopRipe;
        public Block trunkTopFoliage;

        static Random rand = new Random();


        public override void OnLoaded(ICoreAPI api)
        {
            base.OnLoaded(api);

            ICoreServerAPI sapi = api as ICoreServerAPI;
            if (sapi != null)
            {
                if (Code.Path.Equals("coconuttree-normal-trunk10"))
                {
                    sapi.RegisterTreeGenerator(new AssetLocation("coconuttree-normal-trunk10"), this);
                }
            }

            if (trunkThickness6 == null)
            {
                IBlockAccessor blockAccess = api.World.BlockAccessor;

                trunkThickness6 = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunk6"));
                trunkThickness7 = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunk7"));
                trunkThickness8 = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunk8"));
                trunkThickness9 = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunk9"));
                trunkThickness10 = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunk10"));
                
                trunkTopEmpty = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunktopempty"));
                trunkTopFlowering = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunktopflowering"));
                trunkTopUnripe = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunktopunripe"));
                trunkTopRipe = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-trunktopripe"));

                trunkTopFoliage = blockAccess.GetBlock(new AssetLocation("coconuttree-normal-foliage"));
            }
        }

        public override void OnDecalTesselation(IWorldAccessor world, MeshData decalMesh, BlockPos pos)
        {
            base.OnDecalTesselation(world, decalMesh, pos);
        }

        public override void OnJsonTesselation(ref MeshData sourceMesh, ref int[] lightRgbsByCorner, BlockPos pos, Block[] chunkExtBlocks, int extIndex3d)
        {
            base.OnJsonTesselation(ref sourceMesh, ref lightRgbsByCorner, pos, chunkExtBlocks, extIndex3d);

            if (this == trunkTopFoliage)
            {
                for (int i = 0; i < sourceMesh.FlagsCount; i++)
                {
                    sourceMesh.Flags[i] = (sourceMesh.Flags[i] & ~VertexFlags.NormalBitMask) | BlockFacing.UP.NormalPackedFlags;
                }
            }
        }


        public string Type()
        {
            return Variant["type"];
        }


        public void GrowTree(IBlockAccessor blockAccessor, BlockPos pos, bool skipForestFloor, float sizeModifier = 1, float vineGrowthChance = 0, float otherBlockChance = 1, int treesInChunkGenerated = 0)
        {
            float f = otherBlockChance == 0 ? 1 + (float)rand.NextDouble() * 2.5f : 1.5f + (float)rand.NextDouble() * 4;
            int quantity = GameMath.RoundRandom(rand, f);

            while (quantity-- > 0)
            {
                GrowOneTree(blockAccessor, pos.UpCopy(), sizeModifier, vineGrowthChance);

                // Potentially grow another one nearby
                pos.X += rand.Next(8) - 4;
                pos.Z += rand.Next(8) - 4;

                // Test up to 2 blocks up and down.
                bool foundSuitableBlock = false;
                for (int y = 2; y >= -2; y--)
                {
                    //Block block = blockAccessor.GetBlock(pos.X, pos.Y + y, pos.Z);
                    Block block = blockAccessor.GetBlock(pos.X,pos.Y,pos.Z,1);
                    if (block.Fertility > 0 && !blockAccessor.GetBlock(pos.X, pos.Y + y + 1, pos.Z,BlockLayersAccess.Fluid).IsLiquid())
                    {
                        pos.Y = pos.Y + y;
                        foundSuitableBlock = true;
                        break;
                    }
                }
                if (!foundSuitableBlock) break;
            }

            
        }

        private void GrowOneTree(IBlockAccessor blockAccessor, BlockPos upos, float sizeModifier, float vineGrowthChance)
        {
            Block[] thicknesses = new Block[4];
            thicknesses[0] = trunkThickness6;
            thicknesses[1] = trunkThickness7;
            thicknesses[2] = trunkThickness8;
            thicknesses[3] = trunkThickness9;
            thicknesses[4] = trunkThickness10;
            int maxthickness = rand.Next(2);
            int height = GameMath.Clamp((int)(sizeModifier * (float)(2 + rand.Next(6))), 6, 12);
            int[] trunkthicknesses = new int[height];
            for (int tx = 0; tx <= height; tx++)
            {
                if (height - tx < (2 + maxthickness))
                {
                    trunkthicknesses[tx] = height - tx;
                }
                else
                {
                    trunkthicknesses[tx] = 4-maxthickness;
                }
            }
            api.World.Logger.Notification("palm trunk thickness array: {0}", trunkthicknesses);
            // Future note when making fruiting palms- this is supposed to choose one of multiple variants of a fruiting/berry bush type block
            /*
            Block[] trunkTops = new Block[8];
            trunkTops[0] = trunkTopEmpty;
            trunkTops[1] = trunkTopFlowering;
            trunkTops[2] = trunkTopFlowering;
            trunkTops[3] = trunkTopUnripe;
            trunkTops[4] = trunkTopUnripe;
            trunkTops[5] = trunkTopRipe;
            trunkTops[6] = trunkTopRipe;
            trunkTops[7] = trunkTopRipe;
            //if (height == 1) trunkTop = trunkTopYoung;
            */

            // Check that we can actually place the full tree length's blocks
            for (int i = 0; i <= height; i++)  
            {
                Block toplaceblock = trunkThickness6;

                if (!blockAccessor.GetBlock(upos.X, upos.Y + i, upos.Z,BlockLayersAccess.SolidBlocks).IsReplacableBy(toplaceblock)) return;
            }

            for (int i = 0; i <= height; i++)
            {
                Block toplaceblock = trunkThickness6;
                /*
                if (i <= height - 5) toplaceblock = trunkThickness10;
                if (i == height - 5) toplaceblock = trunkThickness9;
                if (i == height - 4) toplaceblock = trunkThickness8;
                if (i == height - 3) toplaceblock = trunkThickness7;
                if (i == height - 2) toplaceblock = trunkThickness6;
                if (i == height - 1) toplaceblock = trunkTops[GameMath.Min(7,rand.Next(8))];
                */
                
                if (i == height) toplaceblock = trunkTopFoliage;
                else toplaceblock = thicknesses[trunkthicknesses[i]];
                api.World.Logger.Notification("placing palm trunk block: {0} at {1}", toplaceblock.BlockId,upos);
                blockAccessor.SetBlock(toplaceblock.BlockId, upos);
                upos.Up();
            }
        }

    }

    public class BlockCoconutFruit : BlockPlant
    {

        public string State => Variant["state"];
        public string Type => Variant["type"];


        public override bool CanPlantStay(IBlockAccessor blockAccessor, BlockPos pos)
        {
            Block belowBlock = blockAccessor.GetBlock(pos.DownCopy(),1);
            if (!(belowBlock is BlockCoconutTree)) return false;
            return true;
        }
    
    }

    public class BlockEntityCoconutFruit : BlockEntity
    {
        static Random rand = new Random();

        double lastCheckAtTotalDays = 0;
        double transitionHoursLeft = -1;
        double? totalDaysForNextStageOld = null; // old v1.13 data format, here for backwards compatibility

        RoomRegistry roomreg;
        public int roomness;

        public BlockEntityCoconutFruit() : base()
        {

        }

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (api is ICoreServerAPI)
            {
                if (transitionHoursLeft <= 0)
                {
                    transitionHoursLeft = GetHoursForNextStage();
                    lastCheckAtTotalDays = api.World.Calendar.TotalDays;
                }

                if (Api.World.Config.GetBool("processCrops", true))
                {
                    RegisterGameTickListener(CheckGrow, 8000);
                }

                roomreg = Api.ModLoader.GetModSystem<RoomRegistry>();

                if (totalDaysForNextStageOld != null)
                {
                    transitionHoursLeft = ((double)totalDaysForNextStageOld - Api.World.Calendar.TotalDays) * Api.World.Calendar.HoursPerDay;
                }
            }
        }

        private void CheckGrow(float dt)
        {
            if (!(Api as ICoreServerAPI).World.IsFullyLoadedChunk(Pos)) return;

            if (Block.Attributes == null)
                {
#if DEBUG
                Api.World.Logger.Notification("Ghost berry bush block entity at {0}. Block.Attributes is null, will remove game tick listener", Pos);
                foreach (long handlerId in TickHandlers)
                {
                    Api.Event.UnregisterGameTickListener(handlerId);
                }
#endif
                return;
            }

            // In case this block was imported from another older world. In that case lastCheckAtTotalDays would be a future date.
            lastCheckAtTotalDays = Math.Min(lastCheckAtTotalDays, Api.World.Calendar.TotalDays);


            // We don't need to check more than one year because it just begins to loop then
            double daysToCheck = GameMath.Mod(Api.World.Calendar.TotalDays - lastCheckAtTotalDays, Api.World.Calendar.DaysPerYear);

            ClimateCondition baseClimate = Api.World.BlockAccessor.GetClimateAt(Pos, EnumGetClimateMode.WorldGenValues);
            if (baseClimate == null) return;
            float baseTemperature = baseClimate.Temperature;

            bool changed = false;
            float oneHour = 1f / Api.World.Calendar.HoursPerDay;
            float resetBelowTemperature = 0, resetAboveTemperature = 0, stopBelowTemperature = 0, stopAboveTemperature = 0, revertBlockBelowTemperature = 0, revertBlockAboveTemperature = 0;
            if (daysToCheck > oneHour)
            {
                resetBelowTemperature = Block.Attributes["resetBelowTemperature"].AsFloat(-999);
                resetAboveTemperature = Block.Attributes["resetAboveTemperature"].AsFloat(999);
                stopBelowTemperature = Block.Attributes["stopBelowTemperature"].AsFloat(-999);
                stopAboveTemperature = Block.Attributes["stopAboveTemperature"].AsFloat(999);
                revertBlockBelowTemperature = Block.Attributes["revertBlockBelowTemperature"].AsFloat(-999);
                revertBlockAboveTemperature = Block.Attributes["revertBlockAboveTemperature"].AsFloat(999);

                if (Api.World.BlockAccessor.GetRainMapHeightAt(Pos) > Pos.Y) // Fast pre-check
                {
                    Room room = roomreg?.GetRoomForPosition(Pos);
                    roomness = (room != null && room.SkylightCount > room.NonSkylightCount && room.ExitCount == 0) ? 1 : 0;
                }
                else
                {
                    roomness = 0;
                }

                changed = true;
            }

            while (daysToCheck > oneHour)
            {
                daysToCheck -= oneHour;
                lastCheckAtTotalDays += oneHour;
                transitionHoursLeft -= 1f;

                baseClimate.Temperature = baseTemperature;
                ClimateCondition conds = Api.World.BlockAccessor.GetClimateAt(Pos, baseClimate, EnumGetClimateMode.ForSuppliedDate_TemperatureOnly, lastCheckAtTotalDays);
                if (roomness > 0)
                {
                    conds.Temperature += 5;
                }

                bool reset =
                    conds.Temperature < resetBelowTemperature ||
                    conds.Temperature > resetAboveTemperature;

                bool stop =
                    conds.Temperature < stopBelowTemperature ||
                    conds.Temperature > stopAboveTemperature;
                
                bool revert = 
                    conds.Temperature < revertBlockBelowTemperature ||
                    conds.Temperature > revertBlockAboveTemperature;

                if (stop || reset)
                {
                    transitionHoursLeft += 1f;
                    
                    if (reset)
                    {
                        transitionHoursLeft = GetHoursForNextStage();
                        if (revert && Block.Variant["part"] != "trunktopempty")
                        {
                            Block nextBlock = Api.World.GetBlock(Block.CodeWithVariant("part", "trunktopempty"));
                            Api.World.BlockAccessor.ExchangeBlock(nextBlock.BlockId, Pos);
                        }
                        

                    }

                    continue;
                }

                if (transitionHoursLeft <= 0)
                {
                    if (!DoGrow()) return;
                    transitionHoursLeft = GetHoursForNextStage();
                }
            }

            if (changed) MarkDirty(false);
        }

        public double GetHoursForNextStage()
        {
            if (IsRipe()) return (4 * (5 + rand.NextDouble()) * 0.8) * Api.World.Calendar.HoursPerDay;

            return ((5 + rand.NextDouble()) * 0.8) * Api.World.Calendar.HoursPerDay;
        }

        public bool IsRipe()
        {
            Block block = Api.World.BlockAccessor.GetBlock(Pos,1);
            return block.LastCodePart() == "trunktopripe";
        }

        bool DoGrow()
        {

            Block block = Api.World.BlockAccessor.GetBlock(Pos,1);
            string nowCodePart = block.LastCodePart();
            string nextCodePart = (nowCodePart == "trunktopempty") ? "trunktopflowering" : ((nowCodePart == "trunktopflowering") ? "trunktopripe" : "trunktopempty");


            AssetLocation loc = block.CodeWithParts(nextCodePart);
            if (!loc.Valid)
            {
                Api.World.BlockAccessor.RemoveBlockEntity(Pos);
                return false;
            }

            Block nextBlock = Api.World.GetBlock(loc);
            if (nextBlock?.Code == null) return false;

            Api.World.BlockAccessor.ExchangeBlock(nextBlock.BlockId, Pos);

            MarkDirty(true);
            return true;
        }


        

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor worldForResolving)
        {
            base.FromTreeAttributes(tree, worldForResolving);

            transitionHoursLeft = tree.GetDouble("transitionHoursLeft");

            if (tree.HasAttribute("totalDaysForNextStage")) // Pre 1.13 format
            {
                totalDaysForNextStageOld = tree.GetDouble("totalDaysForNextStage");
            }

            lastCheckAtTotalDays = tree.GetDouble("lastCheckAtTotalDays");

            roomness = tree.GetInt("roomness");
        }

        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);

            tree.SetDouble("transitionHoursLeft", transitionHoursLeft);
            tree.SetDouble("lastCheckAtTotalDays", lastCheckAtTotalDays);
            tree.SetInt("roomness", roomness);
        }

        public override void GetBlockInfo(IPlayer forPlayer, StringBuilder sb)
        {
            Block block = Api.World.BlockAccessor.GetBlock(Pos,1);
            double daysleft = transitionHoursLeft / Api.World.Calendar.HoursPerDay;

            /*if (forPlayer.WorldData.CurrentGameMode == EnumGameMode.Creative)
            {
                return "" + daysleft;
            }*/

            if (block.LastCodePart() == "trunktopripe")
            {
                return;
            }

            string code = (block.LastCodePart() == "trunktopempty") ? "trunktopflowering" : ( (block.LastCodePart() == "trunktopunripe") ? "trunktopunripe" : "trunktopripe");
    
            if (daysleft < 1)
            {
                sb.AppendLine(Lang.Get("coconut-"+ code + "-1day"));
            }
            else
            {
                sb.AppendLine(Lang.Get("coconut-" + code + "-xdays", (int)daysleft));
            }

            if (roomness > 0)
            {
                sb.AppendLine(Lang.Get("greenhousetempbonus"));
            }
        }

    }

}